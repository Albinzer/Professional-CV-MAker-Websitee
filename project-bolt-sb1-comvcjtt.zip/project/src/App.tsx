import React, { useState } from 'react';
import Header from './components/Header';
import PersonalInfoForm from './components/PersonalInfoForm';
import ExperienceForm from './components/ExperienceForm';
import EducationForm from './components/EducationForm';
import SkillsForm from './components/SkillsForm';
import ProjectsForm from './components/ProjectsForm';
import CVPreview from './components/CVPreview';
import { CVData } from './types/cv';

function App() {
  const [showPreview, setShowPreview] = useState(false);
  const [cvData, setCvData] = useState<CVData>({
    personalInfo: {
      fullName: '',
      email: '',
      phone: '',
      location: '',
      website: '',
      linkedin: '',
      github: '',
      summary: ''
    },
    experience: [],
    education: [],
    skills: [],
    projects: []
  });

  const handleExport = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const cvElement = document.getElementById('cv-preview');
      if (cvElement) {
        printWindow.document.write(`
          <html>
            <head>
              <title>CV - ${cvData.personalInfo.fullName}</title>
              <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
              <style>
                body { font-family: 'Inter', sans-serif; margin: 0; padding: 20px; }
                * { margin: 0; padding: 0; box-sizing: border-box; }
                .text-3xl { font-size: 1.875rem; line-height: 2.25rem; }
                .text-2xl { font-size: 1.5rem; line-height: 2rem; }
                .text-lg { font-size: 1.125rem; line-height: 1.75rem; }
                .text-sm { font-size: 0.875rem; line-height: 1.25rem; }
                .text-xs { font-size: 0.75rem; line-height: 1rem; }
                .font-bold { font-weight: 700; }
                .font-semibold { font-weight: 600; }
                .font-medium { font-weight: 500; }
                .text-gray-900 { color: #111827; }
                .text-gray-700 { color: #374151; }
                .text-gray-600 { color: #4b5563; }
                .text-gray-500 { color: #6b7280; }
                .text-blue-600 { color: #2563eb; }
                .text-green-600 { color: #16a34a; }
                .text-purple-800 { color: #6b21a8; }
                .bg-purple-100 { background-color: #f3e8ff; }
                .bg-gray-200 { background-color: #e5e7eb; }
                .bg-blue-500 { background-color: #3b82f6; }
                .bg-green-500 { background-color: #22c55e; }
                .bg-yellow-500 { background-color: #eab308; }
                .bg-gray-400 { background-color: #9ca3af; }
                .border-b { border-bottom: 1px solid #e5e7eb; }
                .border-l-2 { border-left: 2px solid; }
                .border-blue-500 { border-color: #3b82f6; }
                .border-green-500 { border-color: #22c55e; }
                .border-purple-500 { border-color: #a855f7; }
                .mb-2 { margin-bottom: 0.5rem; }
                .mb-3 { margin-bottom: 0.75rem; }
                .mb-4 { margin-bottom: 1rem; }
                .mb-6 { margin-bottom: 1.5rem; }
                .mb-8 { margin-bottom: 2rem; }
                .mt-4 { margin-top: 1rem; }
                .p-8 { padding: 2rem; }
                .pb-6 { padding-bottom: 1.5rem; }
                .pl-4 { padding-left: 1rem; }
                .px-2 { padding-left: 0.5rem; padding-right: 0.5rem; }
                .py-1 { padding-top: 0.25rem; padding-bottom: 0.25rem; }
                .space-y-2 > * + * { margin-top: 0.5rem; }
                .space-y-4 > * + * { margin-top: 1rem; }
                .space-y-6 > * + * { margin-top: 1.5rem; }
                .space-x-1 > * + * { margin-left: 0.25rem; }
                .space-x-2 > * + * { margin-left: 0.5rem; }
                .flex { display: flex; }
                .flex-wrap { flex-wrap: wrap; }
                .items-center { align-items: center; }
                .items-start { align-items: flex-start; }
                .justify-between { justify-content: space-between; }
                .gap-2 { gap: 0.5rem; }
                .gap-4 { gap: 1rem; }
                .gap-6 { gap: 1.5rem; }
                .grid { display: grid; }
                .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
                .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                .rounded-full { border-radius: 9999px; }
                .overflow-hidden { overflow: hidden; }
                .w-20 { width: 5rem; }
                .w-16 { width: 4rem; }
                .w-full { width: 100%; }
                .w-3/4 { width: 75%; }
                .w-1/2 { width: 50%; }
                .w-1/4 { width: 25%; }
                .h-2 { height: 0.5rem; }
                .h-4 { height: 1rem; }
                .h-full { height: 100%; }
                .leading-relaxed { line-height: 1.625; }
                .whitespace-pre-line { white-space: pre-line; }
                .text-right { text-align: right; }
                .max-w-4xl { max-width: 56rem; }
                .mx-auto { margin-left: auto; margin-right: auto; }
                .shadow-lg { box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); }
                .rounded-lg { border-radius: 0.5rem; }
                .transition-all { transition: all 0.3s; }
                @media (min-width: 768px) {
                  .md\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                }
                @media print {
                  body { font-size: 12px; }
                  .shadow-lg { box-shadow: none; }
                }
              </style>
            </head>
            <body>
              ${cvElement.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
        }, 250);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-inter">
      <Header 
        onTogglePreview={() => setShowPreview(!showPreview)}
        showPreview={showPreview}
        onExport={handleExport}
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className={`grid ${showPreview ? 'lg:grid-cols-2' : 'lg:grid-cols-1'} gap-8`}>
          {/* Forms Section */}
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <PersonalInfoForm 
                data={cvData.personalInfo}
                onChange={(personalInfo) => setCvData({...cvData, personalInfo})}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <ExperienceForm 
                data={cvData.experience}
                onChange={(experience) => setCvData({...cvData, experience})}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <EducationForm 
                data={cvData.education}
                onChange={(education) => setCvData({...cvData, education})}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <SkillsForm 
                data={cvData.skills}
                onChange={(skills) => setCvData({...cvData, skills})}
              />
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <ProjectsForm 
                data={cvData.projects}
                onChange={(projects) => setCvData({...cvData, projects})}
              />
            </div>
          </div>
          
          {/* Preview Section */}
          {showPreview && (
            <div className="lg:sticky lg:top-8 lg:self-start">
              <CVPreview data={cvData} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;